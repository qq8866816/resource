import matplotlib.pyplot as plt
import re
str = """"
  <contour>
        <pt x="91" y="777" on="1"/>
        <pt x="91" y="463" on="1"/>
        <pt x="232" y="463" on="1"/>
        <pt x="232" y="28" on="1"/>
        <pt x="158" y="9" on="1"/>
        <pt x="158" y="356" on="1"/>
        <pt x="94" y="356" on="1"/>
        <pt x="94" y="-7" on="1"/>
        <pt x="41" y="-19" on="1"/>
        <pt x="61" y="-89" on="1"/>
        <pt x="270" y="-39" on="0"/>
        <pt x="426" y="19" on="1"/>
        <pt x="426" y="91" on="1"/>
        <pt x="366" y="69" on="0"/>
        <pt x="299" y="48" on="1"/>
        <pt x="299" y="234" on="1"/>
        <pt x="403" y="234" on="1"/>
        <pt x="403" y="302" on="1"/>
        <pt x="299" y="302" on="1"/>
        <pt x="299" y="463" on="1"/>
        <pt x="399" y="463" on="1"/>
        <pt x="399" y="777" on="1"/>
      </contour>
      <contour>
        <pt x="330" y="529" on="1"/>
        <pt x="161" y="529" on="1"/>
        <pt x="161" y="711" on="1"/>
        <pt x="330" y="711" on="1"/>
      </contour>
      <contour>
        <pt x="876" y="274" on="1"/>
        <pt x="486" y="274" on="1"/>
        <pt x="486" y="-97" on="1"/>
        <pt x="555" y="-97" on="1"/>
        <pt x="555" y="-53" on="1"/>
        <pt x="807" y="-53" on="1"/>
        <pt x="807" y="-97" on="1"/>
        <pt x="876" y="-97" on="1"/>
      </contour>
      <contour>
        <pt x="555" y="13" on="1"/>
        <pt x="555" y="209" on="1"/>
        <pt x="807" y="209" on="1"/>
        <pt x="807" y="13" on="1"/>
      </contour>
      <contour>
        <pt x="588" y="819" on="1"/>
        <pt x="540" y="666" on="0"/>
        <pt x="408" y="563" on="1"/>
        <pt x="451" y="506" on="1"/>
        <pt x="499" y="545" on="0"/>
        <pt x="538" y="589" on="1"/>
        <pt x="575" y="520" on="0"/>
        <pt x="629" y="462" on="1"/>
        <pt x="531" y="384" on="0"/>
        <pt x="393" y="329" on="1"/>
        <pt x="436" y="271" on="1"/>
        <pt x="577" y="331" on="0"/>
        <pt x="678" y="413" on="1"/>
        <pt x="779" y="323" on="0"/>
        <pt x="927" y="275" on="1"/>
        <pt x="968" y="334" on="1"/>
        <pt x="828" y="378" on="0"/>
        <pt x="729" y="459" on="1"/>
        <pt x="827" y="555" on="0"/>
        <pt x="878" y="681" on="1"/>
        <pt x="878" y="733" on="1"/>
        <pt x="630" y="733" on="1"/>
        <pt x="645" y="769" on="0"/>
        <pt x="657" y="806" on="1"/>
      </contour>
      <contour>
        <pt x="579" y="644" on="1"/>
        <pt x="588" y="657" on="0"/>
        <pt x="596" y="669" on="1"/>
        <pt x="802" y="669" on="1"/>
        <pt x="756" y="580" on="0"/>
        <pt x="679" y="505" on="1"/>
        <pt x="619" y="566" on="0"/>
      </contour>
"""
x = [int(i) for i in re.findall(r'<pt x="(.*?)" y=', str)]
y = [int(i) for i in re.findall(r'y="(.*?)" on=', str)]
print(x)
print(y)
plt.plot(x, y)
plt.show()
