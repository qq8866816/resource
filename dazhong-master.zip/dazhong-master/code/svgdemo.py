from fontTools.ttLib import TTFont


def get_cmap():
    """
    分析字体所映射的值
    :param font_nums: 当前页面获取到的数组
    :return:
    """
    # 读取字体
    font = TTFont("font/69d828f2.woff")

    # 生存成xml文件 酿成python可读,举行分析
    font.saveXML('font/69d828f2.xml')

    # 读取字体
    font = TTFont("font/78767531.woff")

    # 生存成xml文件 酿成python可读,举行分析
    font.saveXML('font/78767531.xml')

get_cmap()