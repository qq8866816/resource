from selenium import webdriver
import os

import os
import sys
import time
import pymysql
import traceback

from selenium.common.exceptions import NoSuchElementException
from selenium.webdriver.common.by import By

db = pymysql.connect(host='devdb-m1.db.pajkdc.com', user='locallife', passwd='locallife', db='locallife', port=3308,
                     charset='utf8')


def crawling_data(log_id, city, region, channel, category):
    cursor = db.cursor()
    chrome_driver = "C:/Users/Public/google/Chrome/Application/chromedriver.exe"
    os.environ["webdriver.chrome.driver"] = chrome_driver
    url = "http://www.dianping.com/" + str(city) + "/ch" + str(channel) + "/r" + str(region) + "g" + str(category)
    sql = "INSERT INTO dianping_store (name,category_id,region_id,dianping_shop_id) VALUES(%s,%s,%s,%s)" \
          " ON DUPLICATE KEY UPDATE name=VALUES(name),category_id=VALUES(category_id),region_id=VALUES(" \
          "region_id) "
    values = []
    page = 0
    for i in range(1, 51):
        try:
            page = i
            browser = webdriver.Chrome(chrome_driver)
            browser.get(url + "p" + str(i))
            time.sleep(5)
            shops_len = 0
            shop_all_list = browser.find_elements_by_id("shop-all-list")
            if len(shop_all_list) > 0:
                shops_len = len(shop_all_list[0].find_element_by_tag_name("ul").find_elements_by_tag_name("li"))
            else:
                verify_box_div = browser.find_elements_by_id("yodaBoxWrapper")
                if len(verify_box_div) > 0:
                    print("触发滑块验证:"+url)
                    cursor.execute("update dianping_spider_log set status=4 , page=" + str(page) + " where id=" + str(log_id))
                    db.commit()
                    browser.quit()
                    return
            if shops_len > 0:
                for j in range(1, shops_len + 1):
                    try:
                        shop_tag_a = shop_all_list[0].find_element_by_xpath(
                            "//ul/li[" + str(j) + "]/div[@class='txt']/div[@class='tit']/a")
                        shop_name = shop_tag_a.find_element_by_tag_name("h4").text
                        shop_id = shop_tag_a.get_attribute("data-shopid")
                        if len(shop_name) > 0:
                            values.append((shop_name, str(category), str(region), shop_id))
                    except Exception as e:
                        print(url)
                        traceback.print_exc()
                        cursor.execute("update dianping_spider_log set status=3 , page="+str(i)+" where id=" + str(log_id))
                        db.commit()
                        browser.quit()
                        return
            else:
                browser.quit()
                break
            browser.quit()
        except Exception as e:
            print(url)
            traceback.print_exc()
            cursor.execute("update dianping_spider_log set status=3 , page="+str(i)+" where id=" + str(log_id))
            db.commit()
            browser.quit()
            return
    if len(values) > 0:
        cursor.executemany(sql, values)
        db.commit()
    temp_sql = "update dianping_spider_log set status=2 , page="+str(page)+" where id=" + str(log_id)
    cursor.execute(temp_sql)
    db.commit()
    return


def get_crawling_url():
    cursor = db.cursor()
    retry_count = 0
    while retry_count < 10:
        cursor.execute("select id,city_id,region_id,channel,category_id,page,status from dianping_spider_log where status=0 limit 1")
        row = cursor.fetchone()
        if row is None:
            time.sleep(10)
            retry_count += retry_count
            continue
        else:
            retry_count = 0
            cursor.execute("update dianping_spider_log set status=1 where id=" + str(row[0]))
            db.commit()
            if cursor.rowcount > 0:
                try:
                    crawling_data(row[0], row[1], row[2], row[3], row[4])
                except Exception as e:
                    traceback.print_exc()
                    cursor.execute(
                         "update dianping_spider_log set status=3 where id=" + str(row[0]))
                    db.commit()
            else:
                continue


if __name__ == '__main__':
    get_crawling_url()
