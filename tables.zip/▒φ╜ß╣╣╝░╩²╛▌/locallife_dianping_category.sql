-- MySQL dump 10.13  Distrib 5.7.17, for Win64 (x86_64)
--
-- Host: devdb-m1.db.pajkdc.com    Database: locallife
-- ------------------------------------------------------
-- Server version	5.6.28-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `dianping_category`
--

DROP TABLE IF EXISTS `dianping_category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dianping_category` (
  `id` bigint(20) unsigned NOT NULL COMMENT 'id',
  `category_id` bigint(20) NOT NULL DEFAULT '0' COMMENT '分类id',
  `name` varchar(100) NOT NULL DEFAULT '' COMMENT '分类名',
  `sup_category_id` bigint(20) DEFAULT '0' COMMENT '父分类id',
  PRIMARY KEY (`id`)
);
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dianping_category`
--
-- ORDER BY:  `id`

/*!40000 ALTER TABLE `dianping_category` DISABLE KEYS */;
INSERT INTO `dianping_category` (`id`, `category_id`, `name`, `sup_category_id`) VALUES (1,34116,'',85);
INSERT INTO `dianping_category` (`id`, `category_id`, `name`, `sup_category_id`) VALUES (2,182,'',85);
INSERT INTO `dianping_category` (`id`, `category_id`, `name`, `sup_category_id`) VALUES (3,34045,'',85);
INSERT INTO `dianping_category` (`id`, `category_id`, `name`, `sup_category_id`) VALUES (4,34054,'',85);
INSERT INTO `dianping_category` (`id`, `category_id`, `name`, `sup_category_id`) VALUES (5,34292,'',85);
INSERT INTO `dianping_category` (`id`, `category_id`, `name`, `sup_category_id`) VALUES (6,34050,'',85);
INSERT INTO `dianping_category` (`id`, `category_id`, `name`, `sup_category_id`) VALUES (7,257,'',85);
INSERT INTO `dianping_category` (`id`, `category_id`, `name`, `sup_category_id`) VALUES (8,34297,'',85);
INSERT INTO `dianping_category` (`id`, `category_id`, `name`, `sup_category_id`) VALUES (9,34052,'',85);
INSERT INTO `dianping_category` (`id`, `category_id`, `name`, `sup_category_id`) VALUES (10,34046,'',85);
INSERT INTO `dianping_category` (`id`, `category_id`, `name`, `sup_category_id`) VALUES (11,34193,'',85);
INSERT INTO `dianping_category` (`id`, `category_id`, `name`, `sup_category_id`) VALUES (12,34051,'',85);
INSERT INTO `dianping_category` (`id`, `category_id`, `name`, `sup_category_id`) VALUES (13,34188,'',85);
INSERT INTO `dianping_category` (`id`, `category_id`, `name`, `sup_category_id`) VALUES (14,612,'',85);
INSERT INTO `dianping_category` (`id`, `category_id`, `name`, `sup_category_id`) VALUES (15,34053,'',85);
INSERT INTO `dianping_category` (`id`, `category_id`, `name`, `sup_category_id`) VALUES (16,235,'',85);
INSERT INTO `dianping_category` (`id`, `category_id`, `name`, `sup_category_id`) VALUES (17,2914,'',85);
INSERT INTO `dianping_category` (`id`, `category_id`, `name`, `sup_category_id`) VALUES (18,34190,'',85);
INSERT INTO `dianping_category` (`id`, `category_id`, `name`, `sup_category_id`) VALUES (19,181,'',85);
INSERT INTO `dianping_category` (`id`, `category_id`, `name`, `sup_category_id`) VALUES (20,34191,'',85);
INSERT INTO `dianping_category` (`id`, `category_id`, `name`, `sup_category_id`) VALUES (23,2790,'',50);
INSERT INTO `dianping_category` (`id`, `category_id`, `name`, `sup_category_id`) VALUES (24,157,'',50);
INSERT INTO `dianping_category` (`id`, `category_id`, `name`, `sup_category_id`) VALUES (25,33955,'',50);
INSERT INTO `dianping_category` (`id`, `category_id`, `name`, `sup_category_id`) VALUES (26,34034,'',50);
INSERT INTO `dianping_category` (`id`, `category_id`, `name`, `sup_category_id`) VALUES (27,33956,'',50);
INSERT INTO `dianping_category` (`id`, `category_id`, `name`, `sup_category_id`) VALUES (28,33957,'',50);
INSERT INTO `dianping_category` (`id`, `category_id`, `name`, `sup_category_id`) VALUES (29,159,'',50);
INSERT INTO `dianping_category` (`id`, `category_id`, `name`, `sup_category_id`) VALUES (30,149,'',50);
INSERT INTO `dianping_category` (`id`, `category_id`, `name`, `sup_category_id`) VALUES (31,34281,'',50);
INSERT INTO `dianping_category` (`id`, `category_id`, `name`, `sup_category_id`) VALUES (32,34199,'',50);
INSERT INTO `dianping_category` (`id`, `category_id`, `name`, `sup_category_id`) VALUES (33,148,'',50);
INSERT INTO `dianping_category` (`id`, `category_id`, `name`, `sup_category_id`) VALUES (34,34148,'',70);
INSERT INTO `dianping_category` (`id`, `category_id`, `name`, `sup_category_id`) VALUES (35,34117,'',70);
INSERT INTO `dianping_category` (`id`, `category_id`, `name`, `sup_category_id`) VALUES (36,2784,'',70);
INSERT INTO `dianping_category` (`id`, `category_id`, `name`, `sup_category_id`) VALUES (37,2786,'',70);
INSERT INTO `dianping_category` (`id`, `category_id`, `name`, `sup_category_id`) VALUES (38,2996,'',70);
INSERT INTO `dianping_category` (`id`, `category_id`, `name`, `sup_category_id`) VALUES (39,2788,'',70);
INSERT INTO `dianping_category` (`id`, `category_id`, `name`, `sup_category_id`) VALUES (40,27766,'',70);
INSERT INTO `dianping_category` (`id`, `category_id`, `name`, `sup_category_id`) VALUES (41,27767,'',70);
INSERT INTO `dianping_category` (`id`, `category_id`, `name`, `sup_category_id`) VALUES (42,34146,'',70);
INSERT INTO `dianping_category` (`id`, `category_id`, `name`, `sup_category_id`) VALUES (44,33803,'',70);
INSERT INTO `dianping_category` (`id`, `category_id`, `name`, `sup_category_id`) VALUES (45,27769,'',70);
INSERT INTO `dianping_category` (`id`, `category_id`, `name`, `sup_category_id`) VALUES (46,33797,'',70);
INSERT INTO `dianping_category` (`id`, `category_id`, `name`, `sup_category_id`) VALUES (47,189,'',70);
INSERT INTO `dianping_category` (`id`, `category_id`, `name`, `sup_category_id`) VALUES (48,20009,'',70);
INSERT INTO `dianping_category` (`id`, `category_id`, `name`, `sup_category_id`) VALUES (49,27761,'',70);
INSERT INTO `dianping_category` (`id`, `category_id`, `name`, `sup_category_id`) VALUES (50,27762,'',70);
INSERT INTO `dianping_category` (`id`, `category_id`, `name`, `sup_category_id`) VALUES (51,27763,'',70);
INSERT INTO `dianping_category` (`id`, `category_id`, `name`, `sup_category_id`) VALUES (52,2714,'',10);
INSERT INTO `dianping_category` (`id`, `category_id`, `name`, `sup_category_id`) VALUES (53,34225,'',10);
INSERT INTO `dianping_category` (`id`, `category_id`, `name`, `sup_category_id`) VALUES (54,109,'',10);
INSERT INTO `dianping_category` (`id`, `category_id`, `name`, `sup_category_id`) VALUES (55,140,'',30);
INSERT INTO `dianping_category` (`id`, `category_id`, `name`, `sup_category_id`) VALUES (56,141,'',30);
INSERT INTO `dianping_category` (`id`, `category_id`, `name`, `sup_category_id`) VALUES (57,33844,'',45);
INSERT INTO `dianping_category` (`id`, `category_id`, `name`, `sup_category_id`) VALUES (58,33845,'',45);
INSERT INTO `dianping_category` (`id`, `category_id`, `name`, `sup_category_id`) VALUES (59,151,'',45);
INSERT INTO `dianping_category` (`id`, `category_id`, `name`, `sup_category_id`) VALUES (60,6703,'',45);
INSERT INTO `dianping_category` (`id`, `category_id`, `name`, `sup_category_id`) VALUES (61,34221,'',45);
INSERT INTO `dianping_category` (`id`, `category_id`, `name`, `sup_category_id`) VALUES (62,6704,'',45);
INSERT INTO `dianping_category` (`id`, `category_id`, `name`, `sup_category_id`) VALUES (63,34218,'',45);
INSERT INTO `dianping_category` (`id`, `category_id`, `name`, `sup_category_id`) VALUES (64,34219,'',45);
INSERT INTO `dianping_category` (`id`, `category_id`, `name`, `sup_category_id`) VALUES (65,34220,'',45);
INSERT INTO `dianping_category` (`id`, `category_id`, `name`, `sup_category_id`) VALUES (66,146,'',45);
INSERT INTO `dianping_category` (`id`, `category_id`, `name`, `sup_category_id`) VALUES (67,156,'',45);
INSERT INTO `dianping_category` (`id`, `category_id`, `name`, `sup_category_id`) VALUES (68,152,'',45);
INSERT INTO `dianping_category` (`id`, `category_id`, `name`, `sup_category_id`) VALUES (69,153,'',45);
INSERT INTO `dianping_category` (`id`, `category_id`, `name`, `sup_category_id`) VALUES (70,6702,'',45);
INSERT INTO `dianping_category` (`id`, `category_id`, `name`, `sup_category_id`) VALUES (71,154,'',45);
INSERT INTO `dianping_category` (`id`, `category_id`, `name`, `sup_category_id`) VALUES (72,6712,'',45);
INSERT INTO `dianping_category` (`id`, `category_id`, `name`, `sup_category_id`) VALUES (73,155,'',45);
INSERT INTO `dianping_category` (`id`, `category_id`, `name`, `sup_category_id`) VALUES (74,6706,'',45);
/*!40000 ALTER TABLE `dianping_category` ENABLE KEYS */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed
